package com.example.mycalculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {
    private var op  = ""
    private var old = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val text=findViewById(R.id.text) as EditText

        val btn1=findViewById(R.id.button1) as Button

        btn1.setOnClickListener{
        text.append("1")
        }
        val btn2=findViewById(R.id.button2) as Button

        btn2.setOnClickListener{
            text.append("2")
        }
        val btn3=findViewById(R.id.button3) as Button

        btn3.setOnClickListener{
            text.append("3")
        }
        val btn4=findViewById(R.id.button4) as Button

        btn4.setOnClickListener{
            text.append("4")
        }
        val btn5=findViewById(R.id.button5) as Button

        btn5.setOnClickListener{
            text.append("5")
        }
        val btn6=findViewById(R.id.button6) as Button

        btn6.setOnClickListener{
            text.append("6")
        }
        val btn7=findViewById(R.id.button7) as Button

        btn7.setOnClickListener{
            text.append("7")
        }
        val btn8=findViewById(R.id.button8) as Button

        btn8.setOnClickListener{
            text.append("8")
        }
        val btn9=findViewById(R.id.button9) as Button

        btn9.setOnClickListener{
            text.append("9")
        }
        val btn0=findViewById(R.id.buttonZero) as Button

        btn0.setOnClickListener{
            text.append("0")
        }
        val btnPlus=findViewById(R.id.buttonPlus) as Button
        btnPlus.setOnClickListener(){
            op="+"
            old = text.getText().toString()

            text.setText("")

        }
        val btnMinus=findViewById(R.id.buttonMinus) as Button

        btnMinus.setOnClickListener{
if(text.getText().toString().length == 0){
    text.append("-")
}else {
    op = "-"
    old = text.getText().toString()

    text.setText("")
}
        }
        val btnMultiply=findViewById(R.id.buttonMultiply) as Button

        btnMultiply.setOnClickListener{
            op="*"
            old = text.getText().toString()

            text.setText("")
        }
        val btnDivide=findViewById(R.id.buttonDivide) as Button

        btnDivide.setOnClickListener{
            op="/"
            old = text.getText().toString()

            text.setText("")
                    }
        val btnDot=findViewById(R.id.buttondot) as Button

        btnDot.setOnClickListener{
            if (text.getText().toString().contains(".",false)){
                text.append("")
            }else{
                text.append(".")
            }
        }
        val btnEqual=findViewById(R.id.buttonEqualsTo) as Button
btnEqual.setOnClickListener        {
if(old == ""){
    text.setText("0")
}else {
    when (op) {
        "+" -> {
            text.setText((old.toDouble() + (text.getText().toString()).toDouble()).toString())

        }
        "-" -> {
            text.setText((old.toDouble() - (text.getText().toString()).toDouble()).toString())

        }
        "*" -> {
            text.setText((old.toDouble() * (text.getText().toString()).toDouble()).toString())

        }
        "/" -> {
            text.setText((old.toDouble() / (text.getText().toString()).toDouble()).toString())

        }
    }
}
    }
        val btnCE=findViewById(R.id.CE) as Button

        btnCE.setOnClickListener{
            if (text.getText().toString().length >=1 ){
                 text.setText(text.getText().toString().substring(0,text.getText().toString().length-1))
                }
            else{

                text.setText("")
            }
        }

        val btnCLR=findViewById(R.id.clr) as Button

        btnCLR.setOnClickListener{
            text.setText("")
        }



    }
}